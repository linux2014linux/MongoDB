/*    Copyright 2012 10gen Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

#include "mongo/base/initializer.h"

#include <iostream>
#include "mongo/util/assert_util.h"
#include "mongo/base/global_initializer.h"

namespace mongo {

    Initializer::Initializer() {}
    Initializer::~Initializer() {}

	// 需要执行命令的参数会在此执行
    Status Initializer::execute(const InitializerContext::ArgumentVector& args,
                                const InitializerContext::EnvironmentMap& env) const {

        std::vector<std::string> sortedNodes;
        Status status = _graph.topSort(&sortedNodes);
        if (Status::OK() != status)
            return status;

        InitializerContext context(args, env);

        for (size_t i = 0; i < sortedNodes.size(); ++i) {
            InitializerFunction fn = _graph.getInitializerFunction(sortedNodes[i]);
            if (!fn) {
                return Status(ErrorCodes::InternalError,
                              "topSort returned a node that has no associated function: \"" +
                              sortedNodes[i] + '"');
            }
            try {
				// 这里就是对应参数的执行函数
                status = fn(&context);
            } catch( const DBException& xcp ) {
                return xcp.toStatus();
            }

            if (Status::OK() != status)
                return status;
        }
        return Status::OK();
    }

    Status runGlobalInitializers(const InitializerContext::ArgumentVector& args,
                                 const InitializerContext::EnvironmentMap& env) {
		// 将各个参数保存后，有些参数需要执行相关的命令，会在execute中进行执行
        return getGlobalInitializer().execute(args, env);
    }

    Status runGlobalInitializers(int argc, const char* const* argv, const char* const* envp) {
		// 将argv中的所有参数保存到args中
        InitializerContext::ArgumentVector args(argc);
        std::copy(argv, argv + argc, args.begin());

		// env是key-value结构，用以保存envp的参数与value
		// 在initializer_context.cpp文件中如此定义typedef std::map<std::string, std::string> EnvironmentMap;
        InitializerContext::EnvironmentMap env;

        if (envp) {
			// 解析envp参数
            for(; *envp; ++envp) {
                const char* firstEqualSign = strchr(*envp, '=');
                if (!firstEqualSign) {
                    return Status(ErrorCodes::BadValue, "malformed environment block");
                }
				// 将envp的每一个参数以key-value的形式保存在evn中
                env[std::string(*envp, firstEqualSign)] = std::string(firstEqualSign + 1);
            }
        }

		// 解析args参数，即argv参数
        return runGlobalInitializers(args, env);
    }

    void runGlobalInitializersOrDie(int argc, const char* const* argv, const char* const* envp) {
        Status status = runGlobalInitializers(argc, argv, envp);
        if (!status.isOK()) {
            std::cerr << "Failed global initialization: " << status << std::endl;
            ::_exit(1);
        }
    }

}  // namespace mongo
